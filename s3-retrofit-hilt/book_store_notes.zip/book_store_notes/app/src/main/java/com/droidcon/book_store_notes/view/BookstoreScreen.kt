package com.droidcon.book_store_notes.view

import androidx.compose.material.Text
import androidx.compose.runtime.Composable

@Composable
fun BookstoreScreen() {
    Text(text = "Bookstore screen")
}