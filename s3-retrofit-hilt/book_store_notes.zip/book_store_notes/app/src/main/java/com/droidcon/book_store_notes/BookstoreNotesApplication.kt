package com.droidcon.book_store_notes

import android.app.Application

class BookstoreNotesApplication: Application() {
}